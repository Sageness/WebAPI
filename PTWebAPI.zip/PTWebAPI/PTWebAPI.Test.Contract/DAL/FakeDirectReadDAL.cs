using System.Collections.Generic;
using System.Linq;
using PTWebAPI.Interfaces;
using PTWebAPI.Models.DirectRead.Data;
using PTWebAPI.Models.DirectRead.Request;

namespace PTWebAPI.Test.Contract.DAL
{
    public class FakeDirectReadDAL : IDirectReadDAL
    {
        public List<ClaimOrder> GetClaimDetailsByOrderId(SearchClaimsByOrderIdRequest polarisOrders)
        {
            throw new System.NotImplementedException();
        }

        public List<Claim> GetClaimDetailsByReferralId(SearchClaimsByReferralIdRequest referrals)
        {
            throw new System.NotImplementedException();
        }

        public List<ClaimNote> GetClaimNotesByOrderId(List<int> polarisOrderIds)
        {
            throw new System.NotImplementedException();
        }

        public List<ClaimNote> GetClaimNotesByReferralId(List<int> referralIds)
        {
            throw new System.NotImplementedException();
        }

        public List<ClaimDocument> GetClaimDocumentsByReferralId(List<int> referralIds)
        {
            throw new System.NotImplementedException();
        }

        public List<ClaimDocument> GetClaimDocumentsByOrderId(List<int> orderIds)
        { 
            var claimDocuments = Utils.ReadResponseFromFile<ClaimDocument>("DAL/ResponseFiles/document-response.json");

            claimDocuments = claimDocuments.FindAll(x => orderIds.Contains(x.PolarisOrderID)).ToList();

            return claimDocuments.Count != 0
                ? claimDocuments
                : throw new KeyNotFoundException("No documents were found for the specified Order ID(s)!");
        }
        
        
    }
}