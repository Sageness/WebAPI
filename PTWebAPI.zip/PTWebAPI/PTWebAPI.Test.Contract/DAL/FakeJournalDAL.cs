using System.Collections.Generic;
using System.Linq;
using PTWebAPI.Interfaces;
using PTWebAPI.Models.Journal.Data;
using PTWebAPI.Models.Journal.Request;

namespace PTWebAPI.Test.Contract.DAL
{
   public class FakeJournalDal : IJournalDAL
   {
      public List<JournalType> GetJournalTypes()
      {
         var journalTypes = Utils.ReadResponseFromFile<JournalType>("DAL/ResponseFiles/journal-types-response.json");
         
         return journalTypes.Count != 0 
            ? journalTypes
            : throw new KeyNotFoundException("Could not find any Journal Types! This is an emergency!");
      }

      public int PostJournal(PostJournalRequest journalInfo)
      {
         throw new System.NotImplementedException();
      }

      public List<ReferralJournal> GetReferralJournalsByReferralId(List<int> referralIds)
      {
         throw new System.NotImplementedException();
      }

      public List<ReferralJournal> GetReferralJournalsByOrderId(List<int> reqNotesOrderIds)
      {
         var referralJournals = Utils.ReadResponseFromFile<ReferralJournal>("DAL/ResponseFiles/journal-response.json");

         referralJournals = referralJournals.FindAll(x => reqNotesOrderIds.Contains(x.PolarisOrderID)).ToList();

         return referralJournals.Count != 0
            ? referralJournals
            : throw new KeyNotFoundException("No notes were found for the specified Polaris Order ID(s)!");
      }
   }
}