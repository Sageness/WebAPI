using System.Collections.Generic;
using System.IO;
using PactNet;
using PTWebAPI.Test.Contract.SetUp;
using Xunit;
using Xunit.Abstractions;
using IOutput = PactNet.Infrastructure.Outputters.IOutput;

namespace PTWebAPI.Test.Contract
{
    public class PolarisChannelTests : IClassFixture<PtApiHost>
    {
        private readonly ITestOutputHelper _outputHelper;
        private readonly string _pactFilePath;

        public PolarisChannelTests(ITestOutputHelper outputHelper)
        {
            _outputHelper = outputHelper;

            _pactFilePath = Path.Combine(Constants.PactDirectory, "polarischannel-ptwebapi.json");
        }

        [Fact]
        public void GivenValidPactFilePath_ShouldVerifyInteractions()
        {
            // Arrange
            var config = new PactVerifierConfig
            {
                Outputters = new List<IOutput>
                {
                    new XUnitOutputHelper(_outputHelper)
                },
                Verbose = true
            };

            // Act-Assert
            IPactVerifier pactVerifier = new PactVerifier(config);
            pactVerifier.ServiceProvider("PTWebAPI", Constants.ApiHostUri)
                .HonoursPactWith("PolarisChannel")
                .PactUri(_pactFilePath)
                .Verify();
        }
    }
}