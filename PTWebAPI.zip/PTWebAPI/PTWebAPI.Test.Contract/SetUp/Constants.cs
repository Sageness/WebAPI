using Microsoft.Extensions.Configuration;

namespace PTWebAPI.Test.Contract.SetUp
{
    public static class Constants
    {
        public static readonly string PactDirectory = InitializeConfiguration()["PactDirectory"];
        public const string  ApiHostUri = "http://localhost:5000";
        
        
        private static IConfiguration InitializeConfiguration()
        {
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();
            return config;
        }
    }
}