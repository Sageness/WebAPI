using System;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace PTWebAPI.Test.Contract.SetUp
{
    public class PtApiHost : IDisposable
    {
        private readonly IWebHost _webHost;

        public PtApiHost()
        {
            _webHost = WebHost.CreateDefaultBuilder()
                .UseUrls(Constants.ApiHostUri)
                .UseStartup<TestStartUp>()
                .Build();
            
            _webHost.Start();
        }

        public void Dispose()
        {
            _webHost.StopAsync().GetAwaiter().GetResult();
            _webHost.Dispose();
        }

    }
}