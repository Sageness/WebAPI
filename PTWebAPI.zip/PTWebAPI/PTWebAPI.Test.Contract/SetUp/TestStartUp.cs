using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PTWebAPI.Interfaces;
using PTWebAPI.Test.Contract.DAL;

namespace PTWebAPI.Test.Contract.SetUp
{
    public class TestStartUp : Startup
    {
        public TestStartUp(IConfiguration configuration) : base(configuration)
        {
        }
        
        protected override void ConfigureDAL(IServiceCollection services)
        {
            services.AddScoped<IJournalDAL, FakeJournalDal>();
            services.AddScoped<IDirectReadDAL, FakeDirectReadDAL>();
        }
    }
}