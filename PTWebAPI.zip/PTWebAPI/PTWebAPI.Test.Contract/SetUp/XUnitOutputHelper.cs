using PactNet.Infrastructure.Outputters;
using Xunit.Abstractions;

namespace PTWebAPI.Test.Contract.SetUp
{
    public class XUnitOutputHelper : IOutput
    {
        private readonly ITestOutputHelper _output;
       
        public XUnitOutputHelper(ITestOutputHelper output)
        {
            _output = output;
        }
        
        public void WriteLine(string line)
        {
            _output.WriteLine(line);
        }
    }
}