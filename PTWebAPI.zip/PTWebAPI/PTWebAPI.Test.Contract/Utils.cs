using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace PTWebAPI.Test.Contract
{
    public static class Utils
    {
        public static List<T> ReadResponseFromFile<T>(string filePath)
        {
            var responseFilePath = Path.GetFullPath(filePath);
            return ReadResponse(responseFilePath).ToObject<T[]>().ToList();
        }

        private static JToken ReadResponse(string path)
        {
            return JToken.Parse(File.ReadAllText(path));
        }
    }
}