﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security;
using Microsoft.AspNetCore.Mvc;
using PTWebAPI.Helpers;
using PTWebAPI.Interfaces;
using PTWebAPI.Models.DirectRead.Data;
using PTWebAPI.Models.DirectRead.Request;
using PTWebAPI.Models.DirectRead.Response;
using PTWebAPI.Models.Status;

namespace PTWebAPI.Controllers
{
    [Route("[controller]/")]
    [ApiController]
    //[Authorize]
    public class DirectReadController : ControllerBase
    {
       #region Dependencies/Constructor
      private readonly SecurityHelper _sh = new SecurityHelper();
      private readonly UtilityHelper _uh = new UtilityHelper();
      private readonly IDirectReadDAL _pcDal;

      public DirectReadController(IDirectReadDAL pcDal)
      {
         _pcDal = pcDal;
      }
      #endregion
      
       /// <summary>
       /// This method uses a list of Polaris OrderID to retrieve data from the Align database. 
       /// </summary>
       /// <param name="reqClaims">Object containing client oAuth token and list of Polaris Order IDs</param>
       /// <returns></returns>
       [HttpPost]
       [Route("SearchClaimsByOrderId")]
       public JsonResult SearchClaimsByOrderId([FromBody] SearchClaimsByOrderIdRequest reqClaims)
       {
          try
          {
             //Init response
             var res = new SearchClaimsByOrderIdResponse { Status = new GetStatus{ HttpStatusCode = (int) HttpStatusCode.OK }, Claims = new List<ClaimOrder>() };
       
             //First let's validate the OAuth Token and the provided order data
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating input parameters. Check data and/or OAuth token.");
       
             //Now let's get our order details
             res.Claims = _pcDal.GetClaimDetailsByOrderId(reqClaims);
            
             //Trim off orders with empty referral lists
             res.Claims.RemoveAll(x => x.OrderReferrals.Count < 1);

             //Let's count the results and compare against the original list of IDs to see which returned results and which did not. Return 199 if there were some that returned nothing.
             var notFoundIds = _uh.FindNotFoundIds(reqClaims.OrderIds, res.Claims.Select(x=>x.PolarisOrderId).Distinct().ToList());

             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             if (notFoundIds.Count < 1) return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };
             return new JsonResult(new SearchClaimsByOrderIdResponse
             {
                Claims = res.Claims,
                Status = new GetStatus {
                   DisplayMessage = "The request was successful but some IDs did not return data. Please check your filters and try again or check the ErrorMessage for the list of IDs.",
                   ErrorMessage = string.Join(",", notFoundIds),
                   HttpStatusCode = (int) HttpStatusCode.PartialContent
                }})
             {
                StatusCode = (int) HttpStatusCode.PartialContent
             };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new SearchClaimsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no PT Compass referrals found for the specified Order ID(s)!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new SearchClaimsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new SearchClaimsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve order data from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }

       /// <summary>
       /// This method uses a list of Compass Referral IDs to retrieve data from the Align database. 
       /// </summary>
       /// <param name="reqClaims">Object containing client oAuth token and list of Compass Referral IDs</param>
       /// <returns></returns>
       [HttpPost]
       [Route("SearchClaimsByReferralId")]
       public JsonResult SearchClaimsByReferralId([FromBody] SearchClaimsByReferralIdRequest reqClaims)
       {
          try
          {
             //Init response
             var res = new SearchClaimsByReferralIdResponse { Status = new GetStatus{ HttpStatusCode = (int) HttpStatusCode.OK }, Claims = new List<Claim>() };
       
             //First let's validate the OAuth Token and the provided referral data
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating input parameters. Check data and/or OAuth token.");
       
             //Now let's get our referral details
             res.Claims = _pcDal.GetClaimDetailsByReferralId(reqClaims);

             //Let's count the results and compare against the original list of IDs to see which returned results and which did not. Return 199 if there were some that returned nothing.
             var notFoundIds = _uh.FindNotFoundIds(reqClaims.ReferralIds, res.Claims.Select(x=>x.ReferralID).Distinct().ToList());

             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             if (notFoundIds.Count < 1) return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };
             return new JsonResult(new SearchClaimsByReferralIdResponse
             {
                Claims = res.Claims,
                Status = new GetStatus {
                   DisplayMessage = "The request was successful but some IDs did not return data. Please check your filters and try again or check the ErrorMessage for the list of IDs.",
                   ErrorMessage = string.Join(",", notFoundIds),
                   HttpStatusCode = (int) HttpStatusCode.PartialContent
                }})
             {
                StatusCode = (int) HttpStatusCode.PartialContent
             };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new SearchClaimsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no PT Compass referrals found for the specified Referral ID!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new SearchClaimsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new SearchClaimsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve order data from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }
      
       /// <summary>
       /// This method uses a list of Polaris Order IDs to retrieve note data from the Align database. 
       /// </summary>
       /// <param name="reqNotes">Object containing client oAuth token and list of Polaris Order IDs</param>
       /// <returns></returns>
       [HttpPost]
       [Route("SearchClaimNotesByOrderId")]
       public JsonResult SearchClaimNotesByOrderId([FromBody] SearchClaimNotesByOrderIdRequest reqNotes)
       {
          try
          {
             //Init response
             var res = new SearchClaimNotesByOrderIdResponse { Status = new GetStatus {HttpStatusCode = (int) HttpStatusCode.OK}, ClaimNotes = new List<ClaimNote>() };

             //First let's validate the OAuth Token and the provided order data
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating input parameters. Check data and/or OAuth token.");

             //Now let's get our order notes
             res.ClaimNotes = _pcDal.GetClaimNotesByOrderId(reqNotes.OrderIds);
             
             //Let's count the results and compare against the original list of IDs to see which returned results and which did not. Return 199 if there were some that returned nothing.
             var notFoundIds = _uh.FindNotFoundIds(reqNotes.OrderIds, res.ClaimNotes.Select(x=>x.PolarisOrderID).Distinct().ToList());

             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             if (notFoundIds.Count < 1) return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };
             return new JsonResult(new SearchClaimNotesByOrderIdResponse
             {
                ClaimNotes = res.ClaimNotes,
                Status = new GetStatus {
                   DisplayMessage = "The request was successful but some IDs did not return data. Check the ErrorMessage for the list of IDs.",
                   ErrorMessage = string.Join(",", notFoundIds),
                   HttpStatusCode = (int) HttpStatusCode.PartialContent
                }})
             {
                StatusCode = (int) HttpStatusCode.PartialContent
             };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new SearchClaimNotesByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no notes found for the provided Order ID!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new SearchClaimNotesByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new SearchClaimNotesByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve order note from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }

       /// <summary>
       /// This method uses a list of Compass Referral IDs to retrieve note data from the Align database. 
       /// </summary>
       /// <param name="reqNotes">Object containing client oAuth token and list of Compass Referral Ids</param>
       /// <returns></returns>
       [HttpPost]
       [Route("SearchClaimNotesByReferralId")]
       public JsonResult SearchClaimNotesByReferralId([FromBody] SearchClaimNotesByReferralIdRequest reqNotes)
       {
          try
          {
             //Init response
             var res = new SearchClaimNotesByReferralIdResponse { Status = new GetStatus {HttpStatusCode = (int) HttpStatusCode.OK}, ClaimNotes = new List<ClaimNote>() };

             //First let's validate the OAuth Token and the provided order data
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating input parameters. Check data and/or OAuth token.");

             //Now let's get our order notes
             res.ClaimNotes = _pcDal.GetClaimNotesByReferralId(reqNotes.ReferralIds);
                         
             //Let's count the results and compare against the original list of IDs to see which returned results and which did not. Return 199 if there were some that returned nothing.
             var notFoundIds = _uh.FindNotFoundIds(reqNotes.ReferralIds, res.ClaimNotes.Select(x=>x.Referral_ID).Distinct().ToList());

             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             if (notFoundIds.Count < 1) return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };
             return new JsonResult(new SearchClaimNotesByReferralIdResponse
             {
                ClaimNotes = res.ClaimNotes,
                Status = new GetStatus {
                   DisplayMessage = "The request was successful but some IDs did not return data. Check the ErrorMessage for the list of IDs.",
                   ErrorMessage = string.Join(",", notFoundIds),
                   HttpStatusCode = (int) HttpStatusCode.PartialContent
                }})
             {
                StatusCode = (int) HttpStatusCode.PartialContent
             };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new SearchClaimNotesByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no notes found for the provided Order ID!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new SearchClaimNotesByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new SearchClaimNotesByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve order note from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }

       /// <summary>
       /// This method uses a list of Polaris Order IDs to retrieve document data from the Align database. 
       /// </summary>
       /// <param name="reqDocs">Object containing client oAuth token and list of Polaris Order IDs</param>
       /// <returns></returns>
       [HttpPost]
       [Route("SearchClaimDocumentsByOrderId")]
       public JsonResult SearchClaimDocumentsByOrderId([FromBody] SearchClaimDocumentsByOrderIdRequest reqDocs)
       {
          try
          {
             //Init response
             var res = new SearchClaimDocumentsByOrderIdResponse { Status = new GetStatus{ HttpStatusCode = (int) HttpStatusCode.OK }, ClaimDocuments = new List<ClaimDocument>() };
             
             //First let's validate the OAuth Token and the provided order data
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating input parameters. Check data and/or OAuth token.");
       
             //Now let's get our order docs
             res.ClaimDocuments = _pcDal.GetClaimDocumentsByOrderId(reqDocs.OrderIds);
                                      
             //Let's count the results and compare against the original list of IDs to see which returned results and which did not. Return 199 if there were some that returned nothing.
             var notFoundIds = _uh.FindNotFoundIds(reqDocs.OrderIds, res.ClaimDocuments.Select(x=>x.PolarisOrderID).Distinct().ToList());

             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             if (notFoundIds.Count < 1) return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };
             return new JsonResult(new SearchClaimDocumentsByOrderIdResponse
             {
                ClaimDocuments = res.ClaimDocuments,
                Status = new GetStatus {
                   DisplayMessage = "The request was successful but some IDs did not return data. Check the ErrorMessage for the list of IDs.",
                   ErrorMessage = string.Join(",", notFoundIds),
                   HttpStatusCode = (int) HttpStatusCode.PartialContent
                }})
             {
                StatusCode = (int) HttpStatusCode.PartialContent
             };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new SearchClaimDocumentsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no documents found for the provided Order ID(s)!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new SearchClaimDocumentsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new SearchClaimDocumentsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve order documents from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }

       /// <summary>
       /// This method uses a list of Compass Referral IDs to retrieve document data from the Align database. 
       /// </summary>
       /// <param name="reqDocs">Object containing client oAuth token and list of Compass Referral Ids</param>
       /// <returns></returns>
       [HttpPost]
       [Route("SearchClaimDocumentsByReferralId")]
       public JsonResult SearchClaimDocumentsByReferralId([FromBody] SearchClaimDocumentsByReferralIdRequest reqDocs)
       {
          try
          {
             //Init response
             var res = new SearchClaimDocumentsByReferralIdResponse { Status = new GetStatus{ HttpStatusCode = (int) HttpStatusCode.OK }, ClaimDocuments = new List<ClaimDocument>() };
             
             //First let's validate the OAuth Token and the provided order data
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating input parameters. Check data and/or OAuth token.");
       
             //Now let's get our order docs
             res.ClaimDocuments = _pcDal.GetClaimDocumentsByReferralId(reqDocs.ReferralIds);
                                                   
             //Let's count the results and compare against the original list of IDs to see which returned results and which did not. Return 199 if there were some that returned nothing.
             var notFoundIds = _uh.FindNotFoundIds(reqDocs.ReferralIds, res.ClaimDocuments.Select(x=>x.Referral_ID).Distinct().ToList());

             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             if (notFoundIds.Count < 1) return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };
             return new JsonResult(new SearchClaimDocumentsByReferralIdResponse
             {
                ClaimDocuments = res.ClaimDocuments,
                Status = new GetStatus {
                   DisplayMessage = "The request was successful but some IDs did not return data. Check the ErrorMessage for the list of IDs.",
                   ErrorMessage = string.Join(",", notFoundIds),
                   HttpStatusCode = (int) HttpStatusCode.PartialContent
                }})
             {
                StatusCode = (int) HttpStatusCode.PartialContent
             };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new SearchClaimDocumentsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no documents found for the provided Referral ID(s)!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new SearchClaimDocumentsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new SearchClaimDocumentsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve order documents from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }
    }
}
