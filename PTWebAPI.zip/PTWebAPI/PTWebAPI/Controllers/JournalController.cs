﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security;
using Microsoft.AspNetCore.Mvc;
using PTWebAPI.Helpers;
using PTWebAPI.Interfaces;
using PTWebAPI.Models.Journal.Data;
using PTWebAPI.Models.Journal.Request;
using PTWebAPI.Models.Journal.Response;
using PTWebAPI.Models.Status;

namespace PTWebAPI.Controllers
{
   [Route("[controller]/")]
   [ApiController]
   //[Authorize]
    public class JournalController : ControllerBase
    {
       
       #region Dependencies/Constructor
       private readonly SecurityHelper _sh = new SecurityHelper();
       private readonly UtilityHelper _uh = new UtilityHelper();
       private readonly IJournalDAL _jDal;
       public JournalController(IJournalDAL jdal) { _jDal = jdal; }
       #endregion
      
       /// <summary>
       /// This method is a lookup that returns all of the Journal Types stored in the AlignDb LK_JournalTypes table
       /// </summary>
       /// <returns></returns>
       [HttpGet]
       [Route("GetJournalTypes")]
       public JsonResult GetJournalTypes()
       {
          try
          {
             //Init response
             var res = new GetJournalTypesResponse { Status = new GetStatus{ HttpStatusCode = (int) HttpStatusCode.OK }, JournalTypes = new List<JournalType>() };
       
             //Validate request auth
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating the request. Check data and/or Auth Status.");
       
             //Now let's get our order details
             res.JournalTypes = _jDal.GetJournalTypes();
            
             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new GetJournalTypesResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no journal types found! This isn't good!!!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new GetJournalTypesResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new GetJournalTypesResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve Journal Types from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }

              /// <summary>
       /// This method uses a list of Polaris Order IDs to retrieve referral journal data from the Align database. 
       /// </summary>
       /// <param name="reqNotes">Object containing list of Polaris Order IDs</param>
       /// <returns></returns>
       [HttpPost]
       [Route("GetReferralJournalsByOrderId")]
       public JsonResult GetReferralJournalsByOrderId([FromBody] GetReferralJournalsByOrderIdRequest reqNotes)
       {
          try
          {
             //Init response
             var res = new GetReferralJournalsByOrderIdResponse { Status = new GetStatus {HttpStatusCode = (int) HttpStatusCode.OK}, ReferralJournals = new List<ReferralJournal>() };

             //First let's validate the OAuth Token and the provided order data
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating input parameters. Check data and/or OAuth token.");

             //Now let's get our referral journals
             res.ReferralJournals = _jDal.GetReferralJournalsByOrderId(reqNotes.OrderIds);
             
             //Let's count the results and compare against the original list of IDs to see which returned results and which did not. Return 199 if there were some that returned nothing.
             var notFoundIds = _uh.FindNotFoundIds(reqNotes.OrderIds, res.ReferralJournals.Select(x=>x.PolarisOrderID).Distinct().ToList());

             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             if (notFoundIds.Count < 1) return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };

             return new JsonResult(new GetReferralJournalsByOrderIdResponse
             {
                ReferralJournals = res.ReferralJournals,
                Status = new GetStatus {
                   DisplayMessage = "The request was successful but some IDs did not return data. Check the ErrorMessage for the list of IDs.",
                   ErrorMessage = string.Join(",", notFoundIds),
                   HttpStatusCode = (int) HttpStatusCode.PartialContent
                }})
             {
                StatusCode = (int) HttpStatusCode.PartialContent
             };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new GetReferralJournalsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no referral journals found for the provided Order ID!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new GetReferralJournalsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new GetReferralJournalsByOrderIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve referral journals from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }

       /// <summary>
       /// This method uses a list of Compass Referral IDs to retrieve referral journal data from the Align database. 
       /// </summary>
       /// <param name="reqNotes">Object containing list of Compass Referral Ids</param>
       /// <returns></returns>
       [HttpPost]
       [Route("GetReferralJournalsByReferralId")]
       public JsonResult GetReferralJournalsByReferralId([FromBody] GetReferralJournalsByReferralIdRequest reqNotes)
       {
          try
          {
             //Init response
             var res = new GetReferralJournalsByReferralIdResponse { Status = new GetStatus {HttpStatusCode = (int) HttpStatusCode.OK}, ReferralJournals = new List<ReferralJournal>() };

             //First let's validate the OAuth Token and the provided order data
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating input parameters. Check data and/or OAuth token.");

             //Now let's get our referral journals
             res.ReferralJournals = _jDal.GetReferralJournalsByReferralId(reqNotes.ReferralIds);
                         
             //Let's count the results and compare against the original list of IDs to see which returned results and which did not. Return 199 if there were some that returned nothing.
             var notFoundIds = _uh.FindNotFoundIds(reqNotes.ReferralIds, res.ReferralJournals.Select(x=>x.Referral_ID).Distinct().ToList());

             //If all Ids returned results, let's just return our list. Otherwise let's return the list with a partial-content flag and alert the user of the IDs that returned nothing
             if (notFoundIds.Count < 1) return new JsonResult(res){ StatusCode = (int) HttpStatusCode.OK };
             return new JsonResult(new GetReferralJournalsByReferralIdResponse
             {
                ReferralJournals = res.ReferralJournals,
                Status = new GetStatus {
                   DisplayMessage = "The request was successful but some IDs did not return data. Check the ErrorMessage for the list of IDs.",
                   ErrorMessage = string.Join(",", notFoundIds),
                   HttpStatusCode = (int) HttpStatusCode.PartialContent
                }})
             {
                StatusCode = (int) HttpStatusCode.PartialContent
             };
          }
          catch (KeyNotFoundException ex)
          {
             return new JsonResult(new GetReferralJournalsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There were no referral journals found for the provided Order ID!",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.OK
                }})
             {
                StatusCode = (int) HttpStatusCode.OK
             };
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new GetReferralJournalsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new GetReferralJournalsByReferralIdResponse
             {
                Status = new GetStatus{
                   DisplayMessage = "An error was encountered trying to retrieve referral journals from the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }
      
       [HttpPost]
       [Route("PostJournal")]
       public JsonResult PostJournal([FromBody] PostJournalRequest newJournal)
       {
          try
          {
             var res = new PostJournalResponse { Status = new PostStatus{ HttpStatusCode = (int) HttpStatusCode.OK }};
            
             //Validate request auth
             if (!_sh.ValidateAuth(Request))
                throw new SecurityException(
                   "There was a problem validating the request. Check data and/or Auth Status.");

             res.Status.NewId = _jDal.PostJournal(newJournal);

             return new JsonResult(res){StatusCode = (int) HttpStatusCode.OK};
          }
          catch (SecurityException ex)
          {
             return new JsonResult(new PostJournalResponse
             {
                Status = new PostStatus {
                   DisplayMessage = "There was a problem encountered trying to validate authorization to the API. Please re-authenticate and try again.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.Forbidden
                }})
             {
                StatusCode = (int) HttpStatusCode.Forbidden
             };
          }
          catch (Exception ex)
          {
             return new JsonResult(new PostJournalResponse
             {
                Status = new PostStatus {
                   DisplayMessage = "An error was encountered trying to post a new journal to the Align Database.",
                   ErrorMessage = $"Error: {ex.Message}",
                   HttpStatusCode = (int) HttpStatusCode.InternalServerError
                }})
             {
                StatusCode = (int) HttpStatusCode.InternalServerError
             };
          }
       }

    }
}
