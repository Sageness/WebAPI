﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using Microsoft.Extensions.Configuration;
using PTWebAPI.Interfaces;
using PTWebAPI.Models.DirectRead.Data;
using PTWebAPI.Models.DirectRead.Request;

namespace PTWebAPI.DAL
{
   // ReSharper disable once InconsistentNaming

   public class DirectReadDAL : IDirectReadDAL
   {
       private readonly IConfiguration _configuration;
       public DirectReadDAL(IConfiguration configuration) { _configuration = configuration; }

       #region Public Methods
       /// <summary>
       /// Retrieve the details for the requested Polaris Order IDs
       /// </summary>
       /// <param name="polarisOrders">List of polaris Order IDs</param>
       /// <returns></returns>
       public List<ClaimOrder> GetClaimDetailsByOrderId(SearchClaimsByOrderIdRequest polarisOrders)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             //First let's get our list of referrals from the order Ids
             var odl = GetClaimDetailsByOrderIdFromDb(conn, GenerateTvpTableFromIntList(polarisOrders.OrderIds), polarisOrders.ReferralStatus);
             
             //Throw 404 error if nothing is found
             if (odl == null || odl.Count < 1) throw new KeyNotFoundException("No claims found from the provided dataset!");
             
             //Get the RX data for our referrals
             odl = GrabAndAssignClaimRxData(conn, odl, polarisOrders.DateFrom ?? DateTime.Now.AddYears(-50), polarisOrders.DateTo ?? DateTime.Now.AddYears(100));

             //Build and return our final object
             return polarisOrders.OrderIds.Distinct().Select(orderId => 
               new ClaimOrder
               {
                  PolarisOrderId = orderId, 
                  OrderReferrals = odl.Where(x => x.PolarisOrderId == orderId).ToList()
               }).ToList();
          }
       }
       
       /// <summary>
       /// Retrieve the details for the requested Referral IDs
       /// </summary>
       /// <param name="referrals"></param>
       /// <returns></returns>
       public List<Claim> GetClaimDetailsByReferralId(SearchClaimsByReferralIdRequest referrals)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             //Get bulk of details
             var rdl = GetClaimDetailsByReferralIdFromDb(conn, GenerateTvpTableFromIntList(referrals.ReferralIds), referrals.ReferralStatus);
             
             //Throw 404 error if nothing is found
             if (rdl == null || rdl.Count < 1) throw new KeyNotFoundException("No orders found from the provided dataset!");
             
             //Get the RX data for our referrals
             rdl = GrabAndAssignClaimRxData(conn, rdl, referrals.DateFrom ?? DateTime.Now.AddYears(-50), referrals.DateTo ?? DateTime.Now.AddYears(100));

             return rdl;
          }
       }
      
       /// <summary>
       /// Grabs all of the claim notes for the specified list of Polaris Order Ids
       /// </summary>
       /// <param name="polarisOrderIds"></param>
       /// <returns></returns>
       public List<ClaimNote> GetClaimNotesByOrderId(List<int> polarisOrderIds)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             var notes = GetClaimNotesFromDbByOrderId(conn, GenerateTvpTableFromIntList(polarisOrderIds));

             if (notes == null || notes.Count < 1)
                throw new KeyNotFoundException("No notes were found for the specified Polaris Order ID(s)!");
             
             //Work the list into the return object and return
             return (
                from orderId in polarisOrderIds.Distinct() 
                let onl = notes.Where(x => x.PolarisOrderID == orderId).ToList() 
                where onl != null && onl.Count > 0 
                select new ClaimNote {PolarisOrderID = orderId, PolarisOrderItemID = onl.First().PolarisOrderItemID, Referral_ID = onl.First().Referral_ID, ClaimNotesList = onl}).ToList();
          }
       }
      
       /// <summary>
       /// Grabs all of the claim notes for the specified list of Compass Referral Ids
       /// </summary>
       /// <param name="referralIds"></param>
       /// <returns></returns>
       public List<ClaimNote> GetClaimNotesByReferralId(List<int> referralIds)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             var notes = GetClaimNotesFromDbByReferralId(conn, GenerateTvpTableFromIntList(referralIds));

             if (notes == null || notes.Count < 1)
                throw new KeyNotFoundException("No notes were found for the specified Referral ID(s)!");
             
             //Work the list into the return object and return
             return (
                from referralId in referralIds.Distinct() 
                let onl = notes.Where(x => x.Referral_ID == referralId).ToList() 
                where onl != null && onl.Count > 0 
                select new ClaimNote {PolarisOrderID = onl.First().PolarisOrderID, PolarisOrderItemID = onl.First().PolarisOrderItemID, Referral_ID = referralId, ClaimNotesList = onl}).ToList();
          }
       }
       
       /// <summary>
       /// Grabs document data for the specified list of Polaris Order Ids
       /// </summary>
       /// <param name="orderIds">List of Polaris Order Ids</param>
       /// <returns></returns>
       public List<ClaimDocument> GetClaimDocumentsByOrderId(List<int> orderIds)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             var docs = GetClaimDocsFromDbByOrderId(conn, GenerateTvpTableFromIntList(orderIds));

             if (docs == null || docs.Count < 1)
                throw new KeyNotFoundException("No documents were found for the specified Order ID(s)!");

             //Loop through each file and add our file link prefix
             foreach (var d in docs) d.FileLocation = $"{_configuration["OrderDetailFilePathPrefix"]}{d.FileLocation}";
             
             //Work the list into the return object and return
             return (
                from orderId in orderIds.Distinct() 
                let odl = docs.Where(x => x.PolarisOrderID == orderId).ToList() 
                where odl != null && odl.Count > 0 
                select new ClaimDocument {PolarisOrderID = orderId, PolarisOrderItemID = odl.First().PolarisOrderItemID, Referral_ID = odl.First().Referral_ID, ClaimDocumentsList = odl}).ToList();
          }
       }
       
       /// <summary>
       /// Grabs document data for the specified list of Referral Ids
       /// </summary>
       /// <param name="referralIds">List of Referral Ids</param>
       /// <returns></returns>
       public List<ClaimDocument> GetClaimDocumentsByReferralId(List<int> referralIds)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             var docs = GetClaimDocsFromDbByReferralId(conn, GenerateTvpTableFromIntList(referralIds));

             if (docs == null || docs.Count < 1)
                throw new KeyNotFoundException("No documents were found for the specified Referral ID(s)!");

             //Loop through each file and add our file link prefix
             foreach (var d in docs) d.FileLocation = $"{_configuration["OrderDetailFilePathPrefix"]}{d.FileLocation}";
             
             //Work the list into the return object and return
             return (
                from referralId in referralIds.Distinct() 
                let odl = docs.Where(x => x.Referral_ID == referralId).ToList() 
                where odl != null && odl.Count > 0 
                select new ClaimDocument {PolarisOrderID = odl.First().PolarisOrderID, PolarisOrderItemID = odl.First().PolarisOrderItemID, Referral_ID = referralId, ClaimDocumentsList = odl}).ToList();
          }
       }
       #endregion

       #region Helper Methods

       /// <summary>
       /// Helper method that grabs and associates RxDetail data to the master claim list
       /// </summary>
       /// <param name="conn">SQL Connection </param>
       /// <param name="claims">List of claims that we previously got from the DB</param>
       /// <param name="dateFrom"></param>
       /// <param name="dateTo"></param>
       /// <returns></returns>
       private static List<Claim> GrabAndAssignClaimRxData(IDbConnection conn, List<Claim> claims, DateTime dateFrom, DateTime dateTo)
       {
          //Get our referral ID datatable initialized
          var referralIds = GenerateTvpTableFromIntList(claims.Where(o => o.ReferralID > 0).Select(o => o.ReferralID).ToList());

          //If we have no referral IDs, then just return the list
          if (referralIds.Rows.Count < 1) return claims;

          //Get RxHeader data
          var rxHeaders = GetClaimRxHeadersFromDb(conn, referralIds);
          
          //Get RxDetail data (only if we have RxHeader data) using list of RxHeaderIds
          var rxDetails = new List<ClaimRxDetail>();
          if (rxHeaders.Any()) rxDetails = GetClaimRxDetailsFromDb(conn, GenerateTvpTableFromIntList(rxHeaders.Where(rxh => rxh.RXHeaderID > 0).Select(rxh => rxh.RXHeaderID).ToList()));
          
          //Associate child RxDetail records to their parent RxHeader records
          if (rxDetails.Any())
             foreach (var rxHeader in rxHeaders)
               rxHeader.RxDetails = rxDetails.Where(rxd => rxd.RxHeaderID == rxHeader.RXHeaderID).ToList();
             
          //Get Service dates
          var sdList = GetClaimServiceDatesFromDb(conn, referralIds, dateFrom, dateTo);
          
          //If there's nothing to add, just return without looping through anything
          if (!rxHeaders.Any() && !sdList.Any()) return claims;

          
          //Associate RxHeader and Service date data to the parent referral
          foreach (var claim in claims)
          {
             claim.RxHeaders = rxHeaders.Where(rxh => rxh.ReferralID == claim.ReferralID).ToList();

             claim.ServiceDateTimes = sdList.Where(sd => sd.Referral_ID == claim.ReferralID).ToList();
          }

          return claims;
       }
       private static List<ClaimReferral> GrabAndAssignClaimRxData(IDbConnection conn, List<ClaimReferral> claims, DateTime dateFrom, DateTime dateTo)
       {
          //Get our referral ID datatable initialized
          var referralIds = GenerateTvpTableFromIntList(claims.Where(o => o.ReferralID > 0).Select(o => o.ReferralID).ToList());

          //If we have no referral IDs, then just return the list
          if (referralIds.Rows.Count < 1) return claims;

          //Get RxHeader data
          var rxHeaders = GetClaimRxHeadersFromDb(conn, referralIds);
          
          //Get RxDetail data (only if we have RxHeader data) using list of RxHeaderIds
          var rxDetails = new List<ClaimRxDetail>();
          if (rxHeaders.Any()) rxDetails = GetClaimRxDetailsFromDb(conn, GenerateTvpTableFromIntList(rxHeaders.Where(rxh => rxh.RXHeaderID > 0).Select(rxh => rxh.RXHeaderID).ToList()));
          
          //Associate child RxDetail records to their parent RxHeader records
          if (rxDetails.Any())
             foreach (var rxHeader in rxHeaders)
                rxHeader.RxDetails = rxDetails.Where(rxd => rxd.RxHeaderID == rxHeader.RXHeaderID).ToList();
             
          //Get Service dates
          var sdList = GetClaimServiceDatesFromDb(conn, referralIds, dateFrom, dateTo);
          
          //If there's nothing to add, just return without looping through anything
          if (!rxHeaders.Any() && !sdList.Any()) return claims;

          
          //Associate RxHeader and Service date data to the parent referral
          foreach (var claim in claims)
          {
             claim.RxHeaders = rxHeaders.Where(rxh => rxh.ReferralID == claim.ReferralID).ToList();

             claim.ServiceDateTimes = sdList.Where(sd => sd.Referral_ID == claim.ReferralID).ToList();
          }

          return claims;
       }

       /// <summary>
       /// Helper method that converts a list of integers into a dataTable for use in Dapper commands
       /// </summary>
       /// <param name="intList">List of ints</param>
       /// <returns>DataTable with a single Int column</returns>
       private static DataTable GenerateTvpTableFromIntList(List<int> intList)
       {
          var tvpTable = new DataTable();
          tvpTable.Columns.Add(new DataColumn("Ints", typeof(int)));
          foreach (var id in intList.Distinct()) tvpTable.Rows.Add(id);
          return tvpTable;
       }
       #endregion

       #region Dapper DB Calls
       private static List<ClaimReferral> GetClaimDetailsByOrderIdFromDb(IDbConnection conn, DataTable polarisOrderIds, string referralStatus)
       {
          try { return conn.Query<ClaimReferral>("PTDirectRead_SearchClaimsByOrderId", new {PolarisOrderIDs = polarisOrderIds, ReferralStatus = referralStatus}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the referral data using the provided data: {ex.Message}"); }
       }
      
       private static List<Claim> GetClaimDetailsByReferralIdFromDb(IDbConnection conn, DataTable referralIds, string referralStatus)
       {
          try { return conn.Query<Claim>("PTDirectRead_SearchClaimsByReferralId", new {ReferralIDs = referralIds, ReferralStatus = referralStatus}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the referral data using the provided data: {ex.Message}"); }
       }

       private static List<ClaimServiceDate> GetClaimServiceDatesFromDb(IDbConnection conn, DataTable referralIds, DateTime dateFrom, DateTime dateTo)
       {
          try
          {
            //Check dates and reverse if necessary.
            if (dateTo < dateFrom)
            {
               var tempDate = dateTo;
               dateTo = dateFrom;
               dateFrom = tempDate;
            }

            //Set the "time" of DateFrom to 00:00:00 and DateTo to 23:59:00
            var df = dateFrom.Date + new TimeSpan(0, 0, 0);
            var dt = dateTo.Date + new TimeSpan(23, 59, 59);

            return conn.Query<ClaimServiceDate>("PTDirectRead_GetClaimServiceDates", new {ReferralIds = referralIds, DateFrom = df, DateTo = dt}, commandType: CommandType.StoredProcedure).ToList();
          }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the referral service date data: {ex.Message}"); }
       }

       private static List<ClaimRxHeader> GetClaimRxHeadersFromDb(IDbConnection conn, DataTable referralIds)
       {
          try { return conn.Query<ClaimRxHeader>("PTDirectRead_GetClaimRxHeaders", new {ReferralIDs = referralIds}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the referral RxHeader data: {ex.Message}"); }
       }

       private static List<ClaimRxDetail> GetClaimRxDetailsFromDb(IDbConnection conn, DataTable rxHeaderIds)
       {
          try { return conn.Query<ClaimRxDetail>("PTDirectRead_GetClaimRxDetails", new {RxHeaderIds = rxHeaderIds}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the referral RxDetail data: {ex.Message}"); }
       }

       private static List<ClaimNoteDetails> GetClaimNotesFromDbByOrderId(IDbConnection conn, DataTable polarisOrderIds)
       {
          try { return conn.Query<ClaimNoteDetails>("PTDirectRead_GetClaimNotesByOrderId", new {PolarisOrderIDs = polarisOrderIds}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the order notes data using the provided list of Polaris Order IDs: {ex.Message}"); }
       }

       private static List<ClaimNoteDetails> GetClaimNotesFromDbByReferralId(IDbConnection conn, DataTable referralIds)
       {
          try { return conn.Query<ClaimNoteDetails>("PTDirectRead_GetClaimNotesByReferralId", new {ReferralIds = referralIds}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the order notes data using the provided list of Referral IDs: {ex.Message}"); }
       }
      
       private static List<ClaimDocumentDetails> GetClaimDocsFromDbByOrderId(IDbConnection conn, DataTable polarisOrderIds)
       {
          try { return conn.Query<ClaimDocumentDetails>("PTDirectRead_GetClaimDocumentsByOrderId", new {PolarisOrderIDs = polarisOrderIds}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the order documents data using the provided Polaris Order Ids: {ex.Message}"); }
       }

       private static List<ClaimDocumentDetails> GetClaimDocsFromDbByReferralId(IDbConnection conn, DataTable referralId)
       {
          try { return conn.Query<ClaimDocumentDetails>("PTDirectRead_GetClaimDocumentsByReferralId", new {ReferralIds = referralId}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the order documents data using the provided referral Ids: {ex.Message}"); }
       }
       #endregion
    }

}