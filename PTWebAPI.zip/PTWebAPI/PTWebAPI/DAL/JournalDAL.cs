﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using Microsoft.Extensions.Configuration;
using PTWebAPI.Interfaces;
using PTWebAPI.Models.DirectRead.Data;
using PTWebAPI.Models.Journal.Data;
using PTWebAPI.Models.Journal.Request;
using PTWebAPI.Models.Status;

namespace PTWebAPI.DAL
{
    public class JournalDAL : IJournalDAL
    {
       private readonly IConfiguration _configuration;
       public JournalDAL(IConfiguration configuration) { _configuration = configuration; }


       #region Public Methods
       /// <summary>
       /// Calls the PTWebAPI_Journal_GetReferralJournalTypes stored procedure
       /// </summary>
       /// <returns>List of Journal Types from the Align Database</returns>
       public List<JournalType> GetJournalTypes()
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             var jtList = GetJournalTypesFromDb(conn);

             if (jtList.Count < 1) 
                throw new KeyNotFoundException("Could not find any Journal Types! This is an emergency!");

             return jtList;
          }
       }

       /// <summary>
       /// Grabs all of the referral journals for the specified list of Polaris Order Ids
       /// </summary>
       /// <param name="reqNotesOrderIds"></param>
       /// <returns></returns>
       public List<ReferralJournal> GetReferralJournalsByOrderId(List<int> reqNotesOrderIds)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             var notes = GetReferralJournalsFromDbByOrderId(conn, GenerateTvpTableFromIntList(reqNotesOrderIds));

             if (notes == null || notes.Count < 1)
                throw new KeyNotFoundException("No notes were found for the specified Polaris Order ID(s)!");
             
             //Work the list into the return object and return
             return (
                from orderId in reqNotesOrderIds.Distinct() 
                let onl = notes.Where(x => x.PolarisOrderID == orderId).ToList() 
                where onl != null && onl.Count > 0 
                select new ReferralJournal {PolarisOrderID = orderId, PolarisOrderItemID = onl.First().PolarisOrderItemID, Referral_ID = onl.First().Referral_ID, ReferralJournalList = onl}).ToList();
          }
       }
       
       /// <summary>
       /// Grabs all of the Referral Journals for the specified list of Compass Referral Ids
       /// </summary>
       /// <param name="referralIds"></param>
       /// <returns></returns>
       public List<ReferralJournal> GetReferralJournalsByReferralId(List<int> referralIds)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             var notes = GetReferralJournalsFromDbByReferralId(conn, GenerateTvpTableFromIntList(referralIds));

             if (notes == null || notes.Count < 1)
                throw new KeyNotFoundException("No notes were found for the specified Referral ID(s)!");
             
             //Work the list into the return object and return
             return (
                from referralId in referralIds.Distinct() 
                let onl = notes.Where(x => x.Referral_ID == referralId).ToList() 
                where onl != null && onl.Count > 0 
                select new ReferralJournal {PolarisOrderID = onl.First().PolarisOrderID, PolarisOrderItemID = onl.First().PolarisOrderItemID, Referral_ID = referralId, ReferralJournalList = onl}).ToList();
          }
       }

       /// <summary>
       /// Calls the PTWebAPI_Journal_JournalInsert stored procedure
       /// </summary>
       /// <returns>Journal ID of the new Journal</returns>
       public int PostJournal(PostJournalRequest journalInfo)
       {
          using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
          {
             var newJournalId = AddJournalToDb(conn, journalInfo);

             if (newJournalId < 1) 
                throw new Exception("There was a problem inserting the new journal record!");

             return newJournalId;
          }
       }
       #endregion

       #region Helper Methods
       /// <summary>
       /// Helper method that converts a list of integers into a dataTable for use in Dapper commands
       /// </summary>
       /// <param name="intList">List of ints</param>
       /// <returns>DataTable with a single Int column</returns>
       private static DataTable GenerateTvpTableFromIntList(List<int> intList)
       {
          var tvpTable = new DataTable();
          tvpTable.Columns.Add(new DataColumn("Ints", typeof(int)));
          foreach (var id in intList.Distinct()) tvpTable.Rows.Add(id);
          return tvpTable;
       }
       #endregion
      
       #region Dapper Methods
       private static List<JournalType> GetJournalTypesFromDb(IDbConnection conn)
       {
          try { return conn.Query<JournalType>("PTWebAPI_Journal_GetReferralJournalTypes", commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing Journal Types: {ex.Message}"); }
       }

       private static int AddJournalToDb(IDbConnection conn, PostJournalRequest j)
       {
          var p = new DynamicParameters(j);
          p.Add("JournalID", dbType: DbType.Int32, direction: ParameterDirection.Output);

          conn.Execute("PTWebAPI_Journal_JournalInsert", p, commandType: CommandType.StoredProcedure);

          return p.Get<int>("JournalID");
       }
       
       private static List<ReferralJournalDetail> GetReferralJournalsFromDbByOrderId(IDbConnection conn, DataTable polarisOrderIds)
       {
          try { return conn.Query<ReferralJournalDetail>("PTWebAPI_Journal_GetClaimNotesByOrderId", new {PolarisOrderIDs = polarisOrderIds}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the order notes data using the provided list of Polaris Order IDs: {ex.Message}"); }
       }

       private static List<ReferralJournalDetail> GetReferralJournalsFromDbByReferralId(IDbConnection conn, DataTable referralIds)
       {
          try { return conn.Query<ReferralJournalDetail>("PTWebAPI_Journal_GetClaimNotesByReferralId", new {ReferralIds = referralIds}, commandType: CommandType.StoredProcedure).ToList(); }
          catch (Exception ex) { throw new Exception($"There was an issue grabbing the order notes data using the provided list of Referral IDs: {ex.Message}"); }
       }

       #endregion
    }
}
