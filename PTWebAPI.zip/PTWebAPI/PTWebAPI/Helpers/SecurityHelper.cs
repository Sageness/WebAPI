﻿using Microsoft.AspNetCore.Http;
using PTWebAPI.Models.DirectRead.Request;

namespace PTWebAPI.Helpers
{
    public class SecurityHelper
    {  
       /// <summary>
       /// Check the auth of the request.
       /// </summary>
       /// <param name="request"></param>
       /// <returns></returns>
       public bool ValidateAuth(HttpRequest request)
       {
          //TODO: Make this do something once we figure out what kind of authorization we're doing!
          return request != null;
       }
    }
}
