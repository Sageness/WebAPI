﻿using System.Collections.Generic;
using System.Linq;

namespace PTWebAPI.Helpers
{
    public class UtilityHelper
    {
       /// <summary>
       /// Helper method to find differences in two int lists
       /// If the distinct counts of each list are the same, just return an empty list. Otherwise, return a new list containing the Ids that had no results found
       /// </summary>
       /// <param name="requestList"></param>
       /// <param name="responseList"></param>
       /// <returns></returns>
       public List<int> FindNotFoundIds(List<int> requestList, List<int> responseList)
       {
          return requestList.Distinct().Count() == responseList.Distinct().Count() 
             ? new List<int>() 
             : requestList.Except(responseList).ToList();
       }
    }
}
