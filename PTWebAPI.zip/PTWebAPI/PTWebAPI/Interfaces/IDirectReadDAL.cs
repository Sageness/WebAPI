using System.Collections.Generic;
using PTWebAPI.Models.DirectRead.Data;
using PTWebAPI.Models.DirectRead.Request;

namespace PTWebAPI.Interfaces
{
    public interface IDirectReadDAL
    {
        /// <summary>
        /// Retrieve the details for the requested Polaris Order IDs
        /// </summary>
        /// <param name="polarisOrders">List of polaris Order IDs</param>
        /// <returns></returns>
        List<ClaimOrder> GetClaimDetailsByOrderId(SearchClaimsByOrderIdRequest polarisOrders);

        /// <summary>
        /// Retrieve the details for the requested Referral IDs
        /// </summary>
        /// <param name="referrals"></param>
        /// <returns></returns>
        List<Claim> GetClaimDetailsByReferralId(SearchClaimsByReferralIdRequest referrals);

        /// <summary>
        /// Grabs all of the claim notes for the specified list of Polaris Order Ids
        /// </summary>
        /// <param name="polarisOrderIds"></param>
        /// <returns></returns>
        List<ClaimNote> GetClaimNotesByOrderId(List<int> polarisOrderIds);

        /// <summary>
        /// Grabs all of the claim notes for the specified list of Compass Referral Ids
        /// </summary>
        /// <param name="referralIds"></param>
        /// <returns></returns>
        List<ClaimNote> GetClaimNotesByReferralId(List<int> referralIds);

        /// <summary>
        /// Grabs document data for the specified list of Polaris Order Ids
        /// </summary>
        /// <param name="orderIds">List of Polaris Order Ids</param>
        /// <returns></returns>
        List<ClaimDocument> GetClaimDocumentsByOrderId(List<int> orderIds);

        /// <summary>
        /// Grabs document data for the specified list of Referral Ids
        /// </summary>
        /// <param name="referralIds">List of Referral Ids</param>
        /// <returns></returns>
        List<ClaimDocument> GetClaimDocumentsByReferralId(List<int> referralIds);
    }
}