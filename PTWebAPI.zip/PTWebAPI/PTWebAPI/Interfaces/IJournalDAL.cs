using System.Collections.Generic;
using PTWebAPI.Models.Journal.Data;
using PTWebAPI.Models.Journal.Request;

namespace PTWebAPI.Interfaces
{
    public interface IJournalDAL
    {
        /// <summary>
       /// Calls the PTWebAPI_Journal_GetReferralJournalTypes stored procedure
       /// </summary>
       /// <returns>List of Journal Types from the Align Database</returns>
       List<JournalType> GetJournalTypes();
       

       /// <summary>
       /// Calls the PTWebAPI_Journal_JournalInsert stored procedure
       /// </summary>
       /// <returns>Journal ID of the new Journal</returns>
       int PostJournal(PostJournalRequest journalInfo);
       
      
       /// <summary>
       /// Grabs all of the referral journals for the specified list of Polaris Order Ids
       /// </summary>
       /// <param name="reqNotesOrderIds"></param>
       /// <returns></returns>
       List<ReferralJournal> GetReferralJournalsByOrderId(List<int> reqNotesOrderIds);
      
       
       /// <summary>
       /// Grabs all of the Referral Journals for the specified list of Compass Referral Ids
       /// </summary>
       /// <param name="referralIds"></param>
       /// <returns></returns>
       List<ReferralJournal> GetReferralJournalsByReferralId(List<int> referralIds);
       
    }
}