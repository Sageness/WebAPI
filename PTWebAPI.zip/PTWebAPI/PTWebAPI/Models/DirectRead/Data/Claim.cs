﻿using System;
using System.Collections.Generic;

// ReSharper disable InconsistentNaming

namespace PTWebAPI.Models.DirectRead.Data
{
    public class Claim
    {
       public int ReferralID { get; set; }
       public int PolarisOrderID { get; set; }
       public int PolarisOrderItemID { get; set; }
       public int ReferralStatusID { get; set; } 
       public string ReferralStatus { get; set; }
       public int ServiceTypeID { get; set; }
       public string ServiceType { get; set; }
       public string PatientNameFirst { get; set; }
       public string PatientNameLast { get; set; }
       public string ClaimNumber { get; set; }
       public DateTime DateOfInjury { get; set; }
       public string InjuryState { get; set; }
       public string PatientSex { get; set; }
       public int PatientHeightFeet { get; set; } 
       public decimal PatientHeightInches { get; set; }
       public decimal PatientWeightPounds { get; set; }
       public DateTime PatientBirthDate { get; set; }
       public string PatientAddress { get; set; }
       public string PatientCity { get; set; }
       public string PatientState { get; set; }
       public string PatientZip5 { get; set; }
       public string PatientPhoneHome { get; set; }
       public string PatientPhoneWork { get; set; }
       public string PatientPhoneCell { get; set; }
       public string PatientEmail { get; set; }
       public int LanguageID { get; set; }
       public string LanguageDesc { get; set; }
       public int ReferredByID { get; set; } 
       public string ReferredBy { get; set; }
       public string SubmitterType { get; set; }
       public string SubmitterFirstName { get; set; }
       public string SubmitterLastName { get; set; }
       public int BodyPartID { get; set; }
       public string BodyPart { get; set; }
       public int BodyPartSideID { get; set; }
       public string BodyPartSide { get; set; }
       public string ICD101 { get; set; }
       public string ICD102 { get; set; }
       public string ICD103 { get; set; }
       public string ICD104 { get; set; }
       public string ICD105 { get; set; }
       public string ICD106 { get; set; }
       public string ICD107 { get; set; }
       public string ICD108 { get; set; }
       public string ICD109 { get; set; }
       public string ICD1010 { get; set; }
       public string ICD1011 { get; set; }
       public string ICD1012 { get; set; }
       public string AdjusterFirstName { get; set; }
       public string AdjusterLastName { get; set; }
       public string AdjusterPhone { get; set; }
       public string AdjusterExt { get; set; }
       public string AdjusterFax { get; set; }
       public string AdjusterEmail { get; set; }
       public int AdjusterBranchID { get; set; }
       public string AdjusterBranchName { get; set; }
       public string AdjusterBranchAddress1 { get; set; }
       public string AdjusterBranchAddress2 { get; set; }
       public string AdjusterBranchCity { get; set; }
       public string AdjusterBranchState { get; set; }
       public string AdjusterBranchZip { get; set; }
       public string AdjusterCompany { get; set; }
       public int ProviderID { get; set; }
       public string ProviderName { get; set; }
       public string ProviderPhone { get; set; }
       public string ProviderExt { get; set; }
       public string ProviderFax { get; set; }
       public string ProviderEmail { get; set; }
       public string ProviderAddress { get; set; }
       public string ProviderCity { get; set; }
       public string ProviderState { get; set; }
       public string ProviderZip { get; set; }
       public string ContractTypeGroup { get; set; }
       public List<ClaimRxHeader> RxHeaders { get; set; }
       public List<ClaimServiceDate> ServiceDateTimes { get; set; }
    }
}
