﻿using System;
using System.Runtime.Serialization;

namespace PTWebAPI.Models.DirectRead.Data
{
    public class ClaimDocumentDetails
    {
       [IgnoreDataMember]
       public int PolarisOrderID { get; set; }
       [IgnoreDataMember]
       public int Referral_ID { get; set; }
       [IgnoreDataMember]
       public int PolarisOrderItemID { get; set; }
       public int ReferralFile_ID { get; set; }
       public string FileLocation { get; set; }
       public string FileName { get; set; }
       public DateTime CreatedDate { get; set; }
       public DateTime DateOnDocument { get; set; }
       public int ReferralFileTypeID { get; set; }
       public string ReferralFileType { get; set; }
        
    }
}
