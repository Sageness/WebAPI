﻿// ReSharper disable InconsistentNaming

using System.Collections.Generic;

namespace PTWebAPI.Models.DirectRead.Data
{
    public class ClaimNote
    {
       public int PolarisOrderID { get; set; }
       public int Referral_ID { get; set; }
       public int PolarisOrderItemID { get; set; }
       public List<ClaimNoteDetails> ClaimNotesList { get; set; }
    }
}
