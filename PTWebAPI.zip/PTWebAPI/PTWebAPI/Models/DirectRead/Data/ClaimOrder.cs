﻿using System.Collections.Generic;

namespace PTWebAPI.Models.DirectRead.Data
{
    public class ClaimOrder
    {
       public int PolarisOrderId { get; set; }
       public List<ClaimReferral> OrderReferrals { get; set; }
    }
}
