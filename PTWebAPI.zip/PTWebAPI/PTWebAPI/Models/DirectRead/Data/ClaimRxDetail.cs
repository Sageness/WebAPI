﻿using System;
using System.Runtime.Serialization;

// ReSharper disable InconsistentNaming

namespace PTWebAPI.Models.DirectRead.Data
{
    public class ClaimRxDetail
    {
       [IgnoreDataMember]
       public int RxHeaderID { get; set; }
       public int RxDetailID { get; set; }
       public DateTime AuthorizationDate { get; set; }
       public DateTime? ExpirationDate { get; set; }
       public int VisitsAuthorized { get; set; }
       public string AuthorizationNote { get; set; }
    }
}
