﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
// ReSharper disable InconsistentNaming
// ReSharper disable UnusedMember.Global

namespace PTWebAPI.Models.DirectRead.Data
{
    public class ClaimRxHeader
    {
       public int RXHeaderID { get; set; }
       [IgnoreDataMember]
       public int ReferralID { get; set; }
       public string Frequency { get; set; }
       public string RXNote { get; set; }
       public DateTime RXDate { get; set; }
       public string CreatedBy { get; set; }
       public List<ClaimRxDetail> RxDetails { get; set; }
    }
}
