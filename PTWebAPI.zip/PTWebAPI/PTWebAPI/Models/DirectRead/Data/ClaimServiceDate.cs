﻿using System;
using System.Runtime.Serialization;

// ReSharper disable InconsistentNaming

namespace PTWebAPI.Models.DirectRead.Data
{
    public class ClaimServiceDate
    {
       public int RxDetail_ID { get; set; }
       [IgnoreDataMember]
       public int Referral_ID { get; set; }
       public DateTime ServiceDateTime { get; set; }
       public string AppointmentStatus { get; set; }
       public bool IsEvalVisit { get; set; }
       public bool IsBilled { get; set; }
       public bool IsNotesUploaded { get; set; }
       public string OverAuthReason { get; set; }
    }
}
