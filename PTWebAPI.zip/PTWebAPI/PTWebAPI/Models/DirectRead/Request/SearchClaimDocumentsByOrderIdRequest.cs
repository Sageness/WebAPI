﻿using System.Collections.Generic;

namespace PTWebAPI.Models.DirectRead.Request
{
    public class SearchClaimDocumentsByOrderIdRequest
    {
       public List<int> OrderIds { get; set; }
        
    }
}
