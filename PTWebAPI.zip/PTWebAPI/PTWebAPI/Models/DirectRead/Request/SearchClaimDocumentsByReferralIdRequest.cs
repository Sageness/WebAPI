﻿using System.Collections.Generic;

namespace PTWebAPI.Models.DirectRead.Request
{
    public class SearchClaimDocumentsByReferralIdRequest
    {
       public List<int> ReferralIds { get; set; }
        
    }
}
