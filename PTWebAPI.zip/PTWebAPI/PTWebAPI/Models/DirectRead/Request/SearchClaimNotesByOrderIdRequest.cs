﻿using System.Collections.Generic;

namespace PTWebAPI.Models.DirectRead.Request
{
    public class SearchClaimNotesByOrderIdRequest
    {
       public List<int> OrderIds { get; set; }
    }
}
