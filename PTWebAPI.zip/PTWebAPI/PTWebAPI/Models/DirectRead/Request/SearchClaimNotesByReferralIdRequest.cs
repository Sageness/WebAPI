﻿using System.Collections.Generic;

namespace PTWebAPI.Models.DirectRead.Request
{
    public class SearchClaimNotesByReferralIdRequest
    {
       public List<int> ReferralIds { get; set; }
    }
}
