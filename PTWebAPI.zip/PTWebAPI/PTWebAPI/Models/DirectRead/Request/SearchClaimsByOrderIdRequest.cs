﻿using System;
using System.Collections.Generic;

namespace PTWebAPI.Models.DirectRead.Request
{
    public class SearchClaimsByOrderIdRequest
    {
       public List<int> OrderIds { get; set; }
       public DateTime? DateFrom { get; set; }
       public DateTime? DateTo { get; set; }
       public string ReferralStatus { get; set; }
    }
}
