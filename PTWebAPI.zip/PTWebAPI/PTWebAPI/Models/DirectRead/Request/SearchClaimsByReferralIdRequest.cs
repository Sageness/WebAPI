﻿using System;
using System.Collections.Generic;

namespace PTWebAPI.Models.DirectRead.Request
{
    public class SearchClaimsByReferralIdRequest
    {
       public List<int> ReferralIds { get; set; }
       public DateTime? DateFrom { get; set; }
       public DateTime? DateTo { get; set; }
       public string ReferralStatus { get; set; }
    }
}
