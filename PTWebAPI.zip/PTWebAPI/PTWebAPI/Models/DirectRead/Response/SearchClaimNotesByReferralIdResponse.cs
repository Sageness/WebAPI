﻿using System.Collections.Generic;
using PTWebAPI.Models.DirectRead.Data;
using PTWebAPI.Models.Status;

namespace PTWebAPI.Models.DirectRead.Response
{
    public class SearchClaimNotesByReferralIdResponse
    {
       public GetStatus Status { get; set; }
       public List<ClaimNote> ClaimNotes { get; set; }
    }
}
