﻿using System.Collections.Generic;
using PTWebAPI.Models.DirectRead.Data;
using PTWebAPI.Models.Status;

namespace PTWebAPI.Models.DirectRead.Response
{
    public class SearchClaimsByReferralIdResponse
    {
       public GetStatus Status { get; set; }
       public List<Claim> Claims { get; set; }
    }
}
