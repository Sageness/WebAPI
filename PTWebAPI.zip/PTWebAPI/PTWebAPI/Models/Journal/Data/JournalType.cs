﻿namespace PTWebAPI.Models.Journal.Data
{
    public class JournalType
    {
       public int JournalTypeId { get; set; }
       public string JournalTypeDescription { get; set; }
       public bool IsDeleted { get; set; }
       public bool IsSystem { get; set; }
       public bool PolarisUsable { get; set; }
    }
}
