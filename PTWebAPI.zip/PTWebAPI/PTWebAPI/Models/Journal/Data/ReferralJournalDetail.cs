﻿using System;
using System.Runtime.Serialization;

namespace PTWebAPI.Models.Journal.Data
{
    public class ReferralJournalDetail
    {
       [IgnoreDataMember]
       public int PolarisOrderID { get; set; }
       [IgnoreDataMember]
       public int Referral_ID { get; set; }
       [IgnoreDataMember]
       public int PolarisOrderItemID { get; set; }
       public int ReferralJournal_ID { get; set; }
       public int ReferralSchedule_ID { get; set; }
       public int JournalType_ID { get; set; }
       public string JournalType { get; set; }
       public string Notes { get; set; }
       public DateTime? VisitDate { get; set; }
       public string CreatedBy { get; set; }
       public DateTime CreatedDate { get; set; }
    }
}
