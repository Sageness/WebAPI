﻿using System.Collections.Generic;

namespace PTWebAPI.Models.Journal.Request
{
    public class GetReferralJournalsByOrderIdRequest
    {
       public List<int> OrderIds { get; set; }
    }
}
