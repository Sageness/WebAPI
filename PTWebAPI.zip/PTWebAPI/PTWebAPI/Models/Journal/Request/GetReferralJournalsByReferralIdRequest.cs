﻿using System.Collections.Generic;

namespace PTWebAPI.Models.Journal.Request
{
    public class GetReferralJournalsByReferralIdRequest
    {
       public List<int> ReferralIds { get; set; }
    }
}
