﻿using System.ComponentModel.DataAnnotations;

// ReSharper disable InconsistentNaming

namespace PTWebAPI.Models.Journal.Request
{
    public class PostJournalRequest
    {
       [Required]
       public int ReferralID { get; set; }
       [Required]
       public int JournalTypeID { get; set; }
       [Required]
       public string UserEmail { get; set; }
       [Required]
       public string Note { get; set; }
    }
}
