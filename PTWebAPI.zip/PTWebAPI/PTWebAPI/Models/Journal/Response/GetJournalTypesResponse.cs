﻿using System.Collections.Generic;
using PTWebAPI.Models.Journal.Data;
using PTWebAPI.Models.Status;

namespace PTWebAPI.Models.Journal.Response
{
    public class GetJournalTypesResponse
    {
       public GetStatus Status { get; set; }
       public List<JournalType> JournalTypes { get; set; }
    }
}
