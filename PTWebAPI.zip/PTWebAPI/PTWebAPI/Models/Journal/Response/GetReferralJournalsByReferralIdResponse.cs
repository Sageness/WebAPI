﻿using System.Collections.Generic;
using PTWebAPI.Models.Journal.Data;
using PTWebAPI.Models.Status;

namespace PTWebAPI.Models.Journal.Response
{
    public class GetReferralJournalsByReferralIdResponse
    {
       public GetStatus Status { get; set; }
       public List<ReferralJournal> ReferralJournals { get; set; }
    }
}
