﻿using PTWebAPI.Models.Status;

namespace PTWebAPI.Models.Journal.Response
{
    public class PostJournalResponse
    {
       public PostStatus Status { get; set; }
    }
}
