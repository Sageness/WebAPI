﻿

namespace PTWebAPI.Models.Status
{
    public class PostStatus
    {
       public int HttpStatusCode { get; set; }
       public string DisplayMessage { get; set; }
       public string ErrorMessage { get; set; }
       public int NewId { get; set; }
    }
}
