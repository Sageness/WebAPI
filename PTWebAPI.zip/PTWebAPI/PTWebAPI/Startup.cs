﻿using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using PTWebAPI.DAL;
using PTWebAPI.Interfaces;
using Swashbuckle.AspNetCore.Swagger;

namespace PTWebAPI
{
   public class Startup
   {
      private bool IsAuthenticationEnabled => Configuration.GetValue("EnableApiAuth", false);

      public Startup(IConfiguration configuration) { Configuration = configuration; }
      public IConfiguration Configuration { get; }
      
      // This method gets called by the runtime. Use this method to add services to the container.
      public void ConfigureServices(IServiceCollection services)
      {
         services.AddApplicationInsightsTelemetry();
         services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
         services.AddSingleton(Configuration);
         services.AddHealthChecks()
            .AddCheck("DirectRead", () => HealthCheckResult.Healthy(), tags: new[] {"live"});
            
            //.AddSqlServer(
            //connectionString: Configuration["Data:ConnectionStrings:Sql"],
            //healthQuery: "SELECT 1;",
            //name: "sql", 
            //failureStatus: HealthStatus.Degraded,
            //tags: new string[] { "db", "sql", "sqlserver" });
         services.AddSwaggerGen(c =>
         {
            c.SwaggerDoc("v1", new Info { Title = "PT Web API", Version = "v1" });
         });

         //Add OAuth2.0 config
         if (IsAuthenticationEnabled) SetupAuthentication(services);

         ConfigureDAL(services);
      }
    
      // This method sets up OAuth2
      private void SetupAuthentication(IServiceCollection services)
      {
         services.AddAuthentication(x =>
            {
               x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
               x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer("okta", options =>
            {
               options.Authority = Configuration["Auth:IssuerUrl"];
               options.Audience = Configuration["Auth:ClientId"];
            }).AddJwtBearer("AzureAD", options =>
            {
               options.Authority = Configuration["Msal:Authority"];
               options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
               {
                  ValidateIssuer = true,
                  ValidIssuer = Configuration["Msal:ClientId"],
                  ValidateAudience = true,
                  ValidAudiences = Configuration.GetSection("Msal:Audiences").Get<string[]>()
               };
            });
         services.AddAuthorization(options =>
         {
            options.DefaultPolicy = new AuthorizationPolicyBuilder()
               .RequireAuthenticatedUser()
               .AddAuthenticationSchemes("okta", "AzureAD")
               .Build();
         });
      }

      // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
      public void Configure(IApplicationBuilder app, IHostingEnvironment env)
      {
         if (env.IsDevelopment())
         {
            app.UseDeveloperExceptionPage();
         }
         else
         {
            app.UseHsts();
         }

         app.UseHttpsRedirection();
         app.UseMvc();
         app.UseHealthChecks("/health", new HealthCheckOptions
         {
            Predicate = (check) => check.Tags.Contains("live"),
            ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
         });
 
         app.UseHealthChecks("/health/ready", new HealthCheckOptions
         {
            Predicate = (check) => check.Tags.Contains("ready"),
            ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
         });
         
         //Add OAuth2.0 config
         if (IsAuthenticationEnabled) app.UseAuthentication();

         app.UseSwagger(c =>
         {
            c.RouteTemplate = "api-docs/{documentName}/swagger.json";
         });
         app.UseSwaggerUI(c =>
         {

            c.RoutePrefix = "help";
            c.SwaggerEndpoint("../api-docs/v1/swagger.json", "PT Web API V1");
         });
      }
      
      protected virtual void ConfigureDAL(IServiceCollection services)
      {
         services.AddScoped<IJournalDAL, JournalDAL>();
         services.AddScoped<IDirectReadDAL, DirectReadDAL>();
      }

   }
}
